import React from "react";

export default function AddButton({ handleAddTodo }) {
  return (
    <button
      type='button'
      className='btn btn-primary w-25'
      style={{ height: "36px" }}
      onClick={() => handleAddTodo()}
    >
      +
    </button>
  );
}
